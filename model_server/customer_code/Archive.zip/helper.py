import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('helper')

logger.info('Helper was called')
