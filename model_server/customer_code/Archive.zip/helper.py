import logging

logger = logging.getLogger('helper')

def say_hello():
    logger.info('Helper was called')
